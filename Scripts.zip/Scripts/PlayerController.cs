using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    public Animator animator;
    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D)){
            animator.SetBool("RealMoveKey" , true);
            if(Input.GetKey(KeyCode.A)){
                animator.SetBool("FacingLeft" , true);
            }
            else{
                animator.SetBool("FacingLeft" , false);
            }
        }
           
        else{
            animator.SetBool("RealMoveKey" , false);
        }
            
    }
}
