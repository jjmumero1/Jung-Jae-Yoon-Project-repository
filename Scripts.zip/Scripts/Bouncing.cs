using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Bouncing : MonoBehaviour
{
    Rigidbody2D rBody;
    public Vector2 direction;
    public float speed = 3.0f;


    // Start is called before the first frame update
    void Start()
    {
        rBody = GetComponent<Rigidbody2D>();

        int randomNumber = Random.Range(0,2);

        if(randomNumber == 0){
            direction = Vector2.right;
        }

        if(randomNumber == 1){
            direction = Vector2.left;
        }

    }

    // Update is called once per frame
    void Update()
    {


        
    }

    private void FixedUpdate(){
        Vector2 newPosition = rBody.position + direction * speed * Time.fixedDeltaTime;

        rBody.MovePosition(newPosition);
    }

    private void OnCollisionEnter2D(Collision2D collision){
        direction *= -1;
    }
}
